const express = require('express')
const mysql = require('mysql')
const app = express()

// HARDCODED SECRET (secret_scanner 검출 대상)
const AWS_ACCESS_KEY_ID = 'AKIAV1BESFX9KQ2MR7NJ'
const AWS_SECRET_ACCESS_KEY = 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYaX9kQ2mR7nJ'
const STRIPE_SECRET_KEY = 'sk_live_aX9kQ2mR7nJ4wP8bL5vY3cFd'
const DB_PASSWORD = 'super_secret_db_password_123'

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: DB_PASSWORD,
  database: 'shop'
})

app.use(express.json())

// SQL INJECTION (sast_runner 검출 대상)
app.get('/user', (req, res) => {
  const userId = req.query.id
  // 직접 문자열 연결 → SQL injection
  const query = "SELECT * FROM users WHERE id = '" + userId + "'"
  db.query(query, (err, results) => {
    res.json(results)
  })
})

// XSS (sast_runner 검출 대상)
app.get('/search', (req, res) => {
  const keyword = req.query.q
  // 입력값 그대로 HTML에 삽입
  res.send('<html><body>결과: ' + keyword + '</body></html>')
})

// IDOR (인증 없이 다른 유저 데이터 접근)
app.get('/orders/:id', (req, res) => {
  const orderId = req.params.id
  const query = "SELECT * FROM orders WHERE id = " + orderId
  db.query(query, (err, results) => {
    res.json(results)
  })
})

app.listen(3000)
