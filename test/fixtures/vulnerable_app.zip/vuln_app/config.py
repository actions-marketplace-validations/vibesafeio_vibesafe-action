import psycopg2

# HARDCODED SECRETS (Python)
OPENAI_API_KEY = "sk-aX9kQ2mR7nJ4wP8bL5vY3cF6dZ0eH1iU2oA3s4d5e6f7gH8i"
GITHUB_TOKEN = "ghp_aX9kQ2mR7nJ4wP8bL5vY3cF6dZ0eH1iU2oA3"
SECRET_KEY = "django-insecure-abc123xyz789"

# SQL INJECTION (Python)
def get_user(user_id):
    conn = psycopg2.connect("dbname=test")
    cur = conn.cursor()
    # 직접 포맷 문자열 → SQL injection
    cur.execute("SELECT * FROM users WHERE id = '%s'" % user_id)
    return cur.fetchall()

def search_products(keyword):
    conn = psycopg2.connect("dbname=test")
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE name LIKE '%" + keyword + "%'")
    return cur.fetchall()
