import psycopg2

# HARDCODED SECRETS (Python)
OPENAI_API_KEY = "sk-proj-abc123def456ghi789jkl012mno345pqr678stu901vwx"
GITHUB_TOKEN = "ghp_16C7e42F292c6912E169337jJ3YNratHHFv0j"
SECRET_KEY = "django-insecure-abc123xyz789"

# SQL INJECTION (Python)
def get_user(user_id):
    conn = psycopg2.connect("dbname=test")
    cur = conn.cursor()
    # 직접 포맷 문자열 → SQL injection
    cur.execute("SELECT * FROM users WHERE id = '%s'" % user_id)
    return cur.fetchall()

def search_products(keyword):
    conn = psycopg2.connect("dbname=test")
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE name LIKE '%" + keyword + "%'")
    return cur.fetchall()
